﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIController : MonoBehaviour
{
    public void ActivePanelGameOver()
    {
        Debug.Log("Game Over");
    }
}
